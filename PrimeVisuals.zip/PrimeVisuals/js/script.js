/**
 * Prime Visuals - Premium Graphic Design Portfolio
 * Pure JavaScript - No Frameworks
 */

document.addEventListener('DOMContentLoaded', function() {
  // Initialize all modules
  initLoader();
  initNavigation();
  initMobileMenu();
  initScrollAnimations();
  initPortfolio();
  initLightbox();
  initTestimonials();
  initContactForm();
  initFooter();
});

// ========================================
// LOADER
// ========================================
function initLoader() {
  const loader = document.getElementById('loader');
  const mainContent = document.getElementById('main-content');
  
  // Check if already loaded (for cached pages)
  if (document.readyState === 'complete') {
    showMainContent();
  } else {
    setTimeout(showMainContent, 500);
  }
  
  function showMainContent() {
    loader.classList.add('hidden');
    mainContent.style.opacity = '1';
    
    setTimeout(() => {
      loader.style.display = 'none';
    }, 300);
  }
}

// ========================================
// NAVIGATION
// ========================================
function initNavigation() {
  const nav = document.getElementById('nav');
  let lastScroll = 0;
  
  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 50) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
    
    lastScroll = currentScroll;
  });
  
  // Smooth scroll for navigation links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}

// Global scroll function
function scrollToSection(selector) {
  const target = document.querySelector(selector);
  if (target) {
    target.scrollIntoView({ behavior: 'smooth' });
  }
}

// ========================================
// MOBILE MENU
// ========================================
function initMobileMenu() {
  const toggle = document.getElementById('nav-toggle');
  const mobileMenu = document.getElementById('mobile-menu');
  const menuIcon = toggle.querySelector('.menu-icon');
  const closeIcon = toggle.querySelector('.close-icon');
  
  toggle.addEventListener('click', () => {
    const isOpen = mobileMenu.classList.contains('active');
    
    if (isOpen) {
      closeMobileMenu();
    } else {
      openMobileMenu();
    }
  });
  
  // Close on link click
  mobileMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const href = link.getAttribute('href');
      closeMobileMenu();
      setTimeout(() => {
        scrollToSection(href);
      }, 300);
    });
  });
}

function openMobileMenu() {
  const mobileMenu = document.getElementById('mobile-menu');
  const toggle = document.getElementById('nav-toggle');
  const menuIcon = toggle.querySelector('.menu-icon');
  const closeIcon = toggle.querySelector('.close-icon');
  
  mobileMenu.classList.add('active');
  menuIcon.style.display = 'none';
  closeIcon.style.display = 'block';
  document.body.style.overflow = 'hidden';
}

function closeMobileMenu() {
  const mobileMenu = document.getElementById('mobile-menu');
  const toggle = document.getElementById('nav-toggle');
  const menuIcon = toggle.querySelector('.menu-icon');
  const closeIcon = toggle.querySelector('.close-icon');
  
  mobileMenu.classList.remove('active');
  menuIcon.style.display = 'block';
  closeIcon.style.display = 'none';
  document.body.style.overflow = '';
}

// ========================================
// SCROLL ANIMATIONS
// ========================================
function initScrollAnimations() {
  const elements = document.querySelectorAll('.animate-on-scroll');
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });
  
  elements.forEach(el => observer.observe(el));
}

// ========================================
// PORTFOLIO
// ========================================
let currentFilter = 'all';
let searchQuery = '';

function initPortfolio() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const searchInput = document.getElementById('portfolio-search');
  const clearBtn = document.getElementById('clear-filters');
  
  // Filter buttons
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.filter;
      filterPortfolio();
    });
  });
  
  // Search input
  searchInput.addEventListener('input', debounce((e) => {
    searchQuery = e.target.value.toLowerCase();
    filterPortfolio();
  }, 300));
  
  // Clear filters
  clearBtn.addEventListener('click', () => {
    searchInput.value = '';
    searchQuery = '';
    currentFilter = 'all';
    filterBtns.forEach(b => b.classList.remove('active'));
    filterBtns[0].classList.add('active');
    filterPortfolio();
  });
  
  // Click on portfolio items
  document.querySelectorAll('.portfolio-item').forEach(item => {
    item.addEventListener('click', () => {
      openLightbox(item);
    });
  });
}

function filterPortfolio() {
  const items = document.querySelectorAll('.portfolio-item');
  const grid = document.getElementById('portfolio-grid');
  const noResults = document.getElementById('portfolio-no-results');
  let visibleCount = 0;
  
  items.forEach((item, index) => {
    const category = item.dataset.category;
    const title = item.dataset.title.toLowerCase();
    const description = item.dataset.description.toLowerCase();
    const client = (item.dataset.client || '').toLowerCase();
    
    const matchesFilter = currentFilter === 'all' || category === currentFilter;
    const matchesSearch = !searchQuery || 
      title.includes(searchQuery) || 
      description.includes(searchQuery) || 
      client.includes(searchQuery);
    
    if (matchesFilter && matchesSearch) {
      item.classList.remove('hidden');
      item.classList.add('animate-on-scroll');
      visibleCount++;
    } else {
      item.classList.add('hidden');
    }
  });
  
  if (visibleCount === 0) {
    noResults.classList.add('show');
  } else {
    noResults.classList.remove('show');
  }
}

// ========================================
// LIGHTBOX
// ========================================
let lightboxItems = [];
let currentLightboxIndex = 0;

function initLightbox() {
  const lightbox = document.getElementById('lightbox');
  const closeBtn = document.getElementById('lightbox-close');
  const prevBtn = document.getElementById('lightbox-prev');
  const nextBtn = document.getElementById('lightbox-next');
  
  // Close on background click
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) {
      closeLightbox();
    }
  });
  
  // Close button
  closeBtn.addEventListener('click', closeLightbox);
  
  // Navigation
  prevBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    navigateLightbox(-1);
  });
  
  nextBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    navigateLightbox(1);
  });
  
  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    if (!lightbox.classList.contains('active')) return;
    
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') navigateLightbox(-1);
    if (e.key === 'ArrowRight') navigateLightbox(1);
  });
}

function openLightbox(item) {
  const lightbox = document.getElementById('lightbox');
  const img = document.getElementById('lightbox-img');
  const category = document.getElementById('lightbox-category');
  const title = document.getElementById('lightbox-title');
  const description = document.getElementById('lightbox-description');
  const client = document.getElementById('lightbox-client');
  
  // Get visible items for navigation
  lightboxItems = Array.from(document.querySelectorAll('.portfolio-item:not(.hidden)'));
  currentLightboxIndex = lightboxItems.indexOf(item);
  
  // Update content
  updateLightboxContent(item);
  
  // Show lightbox
  lightbox.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function updateLightboxContent(item) {
  const img = document.getElementById('lightbox-img');
  const category = document.getElementById('lightbox-category');
  const title = document.getElementById('lightbox-title');
  const description = document.getElementById('lightbox-description');
  const client = document.getElementById('lightbox-client');
  
  const categoryMap = {
    'logos': 'Logos',
    'branding': 'Branding',
    'social': 'Social Media',
    'posters': 'Posters & Flyers'
  };
  
  img.src = item.querySelector('img').src;
  img.alt = item.dataset.title;
  category.textContent = categoryMap[item.dataset.category] || item.dataset.category;
  title.textContent = item.dataset.title;
  description.textContent = item.dataset.description;
  client.textContent = item.dataset.client;
}

function closeLightbox() {
  const lightbox = document.getElementById('lightbox');
  lightbox.classList.remove('active');
  document.body.style.overflow = '';
}

function navigateLightbox(direction) {
  currentLightboxIndex = (currentLightboxIndex + direction + lightboxItems.length) % lightboxItems.length;
  updateLightboxContent(lightboxItems[currentLightboxIndex]);
}

// ========================================
// TESTIMONIALS CAROUSEL
// ========================================
let currentTestimonial = 0;
let testimonialInterval;

function initTestimonials() {
  const cards = document.querySelectorAll('.testimonial-card');
  const dots = document.querySelectorAll('.testimonial-dot');
  const prevBtn = document.getElementById('testimonial-prev');
  const nextBtn = document.getElementById('testimonial-next');
  
  // Navigation buttons
  prevBtn.addEventListener('click', () => {
    changeTestimonial(-1);
    resetAutoplay();
  });
  
  nextBtn.addEventListener('click', () => {
    changeTestimonial(1);
    resetAutoplay();
  });
  
  // Dots
  dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
      goToTestimonial(index);
      resetAutoplay();
    });
  });
  
  // Auto-play
  startAutoplay();
  
  // Pause on hover
  const carousel = document.querySelector('.testimonials-carousel');
  carousel.addEventListener('mouseenter', stopAutoplay);
  carousel.addEventListener('mouseleave', startAutoplay);
}

function changeTestimonial(direction) {
  const cards = document.querySelectorAll('.testimonial-card');
  const total = cards.length;
  currentTestimonial = (currentTestimonial + direction + total) % total;
  updateTestimonial();
}

function goToTestimonial(index) {
  currentTestimonial = index;
  updateTestimonial();
}

function updateTestimonial() {
  const cards = document.querySelectorAll('.testimonial-card');
  const dots = document.querySelectorAll('.testimonial-dot');
  
  cards.forEach((card, index) => {
    if (index === currentTestimonial) {
      card.classList.add('active');
    } else {
      card.classList.remove('active');
    }
  });
  
  dots.forEach((dot, index) => {
    if (index === currentTestimonial) {
      dot.classList.add('active');
    } else {
      dot.classList.remove('active');
    }
  });
}

function startAutoplay() {
  testimonialInterval = setInterval(() => {
    changeTestimonial(1);
  }, 8000);
}

function stopAutoplay() {
  clearInterval(testimonialInterval);
}

function resetAutoplay() {
  stopAutoplay();
  startAutoplay();
}

// ========================================
// CONTACT FORM
// ========================================
function initContactForm() {
  const form = document.getElementById('contact-form');
  const successMessage = document.getElementById('contact-success');
  const sendAnotherBtn = document.getElementById('send-another');
  
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      submitForm();
    }
  });
  
  sendAnotherBtn.addEventListener('click', () => {
    successMessage.classList.remove('show');
    form.style.display = 'block';
    form.reset();
  });
  
  // Real-time validation
  form.querySelectorAll('input, textarea').forEach(field => {
    field.addEventListener('blur', () => validateField(field));
    field.addEventListener('input', () => {
      if (field.parentElement.classList.contains('error')) {
        validateField(field);
      }
    });
  });
}

function validateForm() {
  const name = document.getElementById('name');
  const email = document.getElementById('email');
  const message = document.getElementById('message');
  
  let isValid = true;
  
  if (!validateField(name)) isValid = false;
  if (!validateField(email)) isValid = false;
  if (!validateField(message)) isValid = false;
  
  return isValid;
}

function validateField(field) {
  const parent = field.parentElement;
  let isValid = true;
  
  if (field.id === 'name') {
    isValid = field.value.trim().length >= 2;
  } else if (field.id === 'email') {
    isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value);
  } else if (field.id === 'message') {
    isValid = field.value.trim().length >= 10;
  }
  
  if (isValid) {
    parent.classList.remove('error');
  } else {
    parent.classList.add('error');
  }
  
  return isValid;
}

function submitForm() {
  const form = document.getElementById('contact-form');
  const successMessage = document.getElementById('contact-success');
  const submitBtn = document.getElementById('submit-btn');
  
  // Disable button
  submitBtn.disabled = true;
  submitBtn.innerHTML = 'Sending...';
  
  // Simulate API call
  setTimeout(() => {
    form.style.display = 'none';
    successMessage.classList.add('show');
    submitBtn.disabled = false;
    submitBtn.innerHTML = `
      Send Message
      <svg class="arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="22" y1="2" x2="11" y2="13"></line>
        <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
      </svg>
    `;
    showToast('Message Sent!', 'Thank you for reaching out. I\'ll get back to you soon!', 'success');
  }, 1500);
}

// ========================================
// FOOTER
// ========================================
function initFooter() {
  // Set current year
  document.getElementById('year').textContent = new Date().getFullYear();
  
  // Scroll to top
  document.getElementById('scroll-to-top').addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
  
  // Footer links smooth scroll
  document.querySelectorAll('.footer-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      scrollToSection(link.getAttribute('href'));
    });
  });
}

// ========================================
// TOAST NOTIFICATIONS
// ========================================
function showToast(title, message, type = 'success') {
  const container = document.getElementById('toast-container');
  
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="toast-title">${title}</div>
    <div class="toast-message">${message}</div>
  `;
  
  container.appendChild(toast);
  
  // Trigger animation
  setTimeout(() => toast.classList.add('show'), 10);
  
  // Remove after delay
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 5000);
}

// ========================================
// UTILITY FUNCTIONS
// ========================================
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}
