# Prime Visuals Portfolio - Pure HTML/CSS/JS

## Overview

Prime Visuals is a premium graphic design portfolio website converted from a React/TypeScript application to pure HTML, CSS, and JavaScript. The site features a modern, minimalist aesthetic with a dark theme and gold accents, showcasing graphic design services and portfolio work.

**Status**: Complete conversion from React to pure HTML/CSS/JS. All functionality preserved without frameworks.

## Technology Stack

- **Frontend**: Pure HTML5, CSS3, Vanilla JavaScript (ES6+)
- **Styling**: Custom CSS with CSS variables, responsive design, animations
- **Fonts**: Poppins (headings), Inter (body)
- **Server**: Python HTTP Server (port 5000)
- **Build Process**: None - Direct static file serving

## Project Structure

```
├── index.html              # Main HTML file with all sections
├── css/
│   └── style.css          # Complete styling with animations
├── js/
│   └── script.js          # All JavaScript functionality
├── assets/                # Portfolio images and icons
│   ├── luxury_brand_logo_mockup.png
│   ├── corporate_branding_kit_layout.png
│   ├── social_media_post_design.png
│   ├── event_poster_design_mockup.png
│   ├── real_estate_logo_design.png
│   ├── restaurant_menu_design.png
│   ├── fitness_social_media_template.png
│   ├── wedding_invitation_design.png
│   ├── designer_professional_portrait.png
│   └── favicon.png
└── .replit                # Replit configuration

```

## Features Implemented

### Core Sections
1. **Loader** - Animated 500ms loader with smooth fade-out
2. **Navigation** - Fixed header with smooth scroll, mobile menu toggle
3. **Hero Section** - Full-screen with title, CTA buttons, stats, portfolio gallery
4. **Portfolio** - Filterable grid (8 items), search, lightbox modal with prev/next
5. **Services** - 4 service cards + 3 pricing packages (Starter, Business, Premium)
6. **Design Process** - 6-step timeline with alternating layout, durations
7. **About** - Designer portrait with badge, bio, values grid (4 items), stats
8. **Testimonials** - 5-item auto-rotating carousel with dots, manual controls
9. **Blog** - 3 blog post cards with category, date, read time
10. **Contact** - Form with validation, WhatsApp/email buttons, working hours
11. **Footer** - Social links, quick links, CTA, copyright

### JavaScript Functionality
- Smooth scrolling navigation
- Mobile menu toggle with animations
- Intersection observer for scroll animations
- Portfolio filtering by category + search
- Lightbox modal with image navigation (prev/next)
- Testimonial carousel with auto-play (8s), manual controls, dots
- Form validation with real-time feedback
- Toast notifications
- Dark theme with gold accent color (HSL 45, 93%, 47%)

## Design System

### Color Palette
- Primary: Gold (HSL 45, 93%, 47%)
- Background: Black (#000000)
- Text: White (#ffffff)
- Accents: Gold with varying opacity (10%, 20%, 30%)
- WhatsApp: #25D366

### Typography
- Heading Font: Poppins (bold, 700)
- Body Font: Inter (regular, 400-600)

### Spacing & Layout
- Container: max-width 80rem (1280px)
- Mobile padding: 1.5rem
- Desktop padding: 3rem
- Section padding: 5rem mobile, 8rem desktop
- Responsive breakpoints: Mobile, Tablet (640px), Desktop (1024px), Large (1280px)

### Animations
- Fade in/up transitions (600ms)
- Scroll animations for section elements
- Carousel transitions (400ms)
- Button hover effects (300ms)
- Smooth transitions throughout

## User Preferences

- Simple, everyday language for communication
- No frameworks or dependencies - pure HTML/CSS/JS only
- Identical visual appearance to original React version
- Beginner-friendly code structure

## Deployment

**Server**: Python HTTP Server on port 5000
**Command**: `python -m http.server 5000 --bind 0.0.0.0`
**Access**: http://localhost:5000 or Replit webview

## Files

- `index.html` (79.5 KB) - All HTML content
- `css/style.css` - Complete styling (2600+ lines)
- `js/script.js` - All interactivity
- `assets/` - 9 portfolio images + favicon

## Notes

- No build process required
- All assets are local files
- Fully responsive on mobile, tablet, and desktop
- Smooth scrolling and animations throughout
- Form currently shows success message (no backend submission)
- Contact WhatsApp link placeholder (update phone number as needed)
